	<link rel="shortcut icon" type="image/x-icon" href="{{ URL::to('admin/assets/img/logo-hotel.png')}} ">
	<link rel="stylesheet" href="{{ URL::to('admin/assets/css/bootstrap.min.css')}} ">
	<link rel="stylesheet" href="{{ URL::to('admin/assets/plugins/fontawesome/css/fontawesome.min.css')}} ">
	<link rel="stylesheet" href="{{ URL::to('admin/assets/plugins/fontawesome/css/all.min.css')}} ">
	<link rel="stylesheet" href="{{ URL::to('admin/assets/css/feathericon.min.css')}} ">
	<link rel="stylehseet" href="https://cdn.oesmith.co.uk/morris-0.5.1.css">
	<link rel="stylesheet" href="{{ URL::to('admin/assets/plugins/morris/morris.css')}} ">
	<link rel="stylesheet" href="{{ URL::to('admin/assets/css/style.css')}} ">
	<link rel="stylesheet" href="{{ URL::to('admin/assets/plugins/fullcalendar/fullcalendar.min.css')}}">

	<link href='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/5.10.0/main.min.css' rel='stylesheet' />

	<link href="{{ URL::to('admin/assets/plugins/RWD-Table-Patterns/dist/css/rwd-table.min.css')}}" rel="stylesheet" type="text/css" media="screen">

	


	<!-- Include datetimepicker CSS -->

	<link rel="stylesheet" type="text/css" href="{{ URL::to ('admin/assets/css/bootstrap-datetimepicker.min.css')}}">