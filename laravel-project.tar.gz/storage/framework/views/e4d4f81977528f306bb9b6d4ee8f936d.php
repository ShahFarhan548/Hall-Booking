<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

    <div class="main-wrapper">
        <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <div class="page-wrapper">
            <div class="content container-fluid">
                <div class="page-header">
                    <div class="row align-items-center">
                        <div class="col">
                            <?php if(session()->has('message')): ?>
                            <div class="alert alert-success">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                                <?php echo e(session()->get('message')); ?>

                            </div>
                            <?php endif; ?>
                            <h3 class="page-title mt-5">Edit Booking</h3>
                        </div>
                    </div>
                </div>


                <form method="POST" action="<?php echo e(route('update_data_confirm', $data->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="row">
                        <div class="col-lg-12">

                        <div class="row formtype">

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Name</label>
                                        <input type="text" class="form-control" required id="sel1" name="name" value="<?php echo e($data -> name); ?>">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Room Type</label>
                                        <select class="form-control" required id="sel2" name="room_type" value="<?php echo e($data -> room_type); ?>">
                                            <option>Normal Room</option>
                                            <option>Video Room</option>
                                            <option>DOubledBed Room</option>
                                            <option>TripleBed Room</option>
                                            <option>AC Room</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Room number</label>
                                        <input type="number" class="form-control" required id="sel1" name="room_number" value="<?php echo e($data -> room_number); ?>">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label> Date</label>
                                        <div class="cal-icon">
                                            <input type="text" class="form-control datetimepicker" required name="date" value="<?php echo e($data -> date); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Time</label>
                                        <div class="time-icon">
                                            <input type="text" class="form-control datetimepicker3" required id="datetimepicker3" name="time" value="<?php echo e($data -> time); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label> Arrival Date</label>
                                        <div class="cal-icon">
                                            <input type="text" class="form-control  datetimepicker" required name="arrival_date" value="<?php echo e($data -> arrival_date); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Departure Date</label>
                                        <div class="cal-icon">
                                            <input type="text" class="form-control  datetimepicker" required name="departure_date" value="<?php echo e($data -> departure_date); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Email ID</label>
                                        <input type="email" class="form-control" required id="usr" name="email_id" value="<?php echo e($data -> email_id); ?>">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Phone Number</label>
                                        <input type="text" class="form-control" required id="usr1" name="ph_number" value="<?php echo e($data -> ph_number); ?>">
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Message</label>
                                        <textarea class="form-control" rows="5" id="comment" name="message"><?php echo e($data -> message); ?></textarea>
                                    </div>
                                </div>
                            </div>
                    </div>
                    <button type="submit" class="btn btn-primary buttonedit" name="submit" value="Save">Save</button>
                </form>
            </div>
        </div>

    </div>


    <?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\Users\farha\OneDrive\Desktop\HotelManagementSystem-master\resources\views\admin\booking\editbooking.blade.php ENDPATH**/ ?>