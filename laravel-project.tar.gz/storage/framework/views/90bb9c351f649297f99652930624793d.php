<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <title>Hotel Dashboard Template</title>
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <div class="main-wrapper">
        <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="page-wrapper">
            <div class="content container-fluid">

                <div class="page-header">
                    <div id="popup-container">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="mt-5">
                                    <?php if(session()->has('message')): ?>
                                    <div class="alert alert-success">
                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                                        <?php echo e(session()->get('message')); ?>

                                    </div>
                                    <?php endif; ?>
                                </div>
                                <h4 class="card-title float-left mt-2">Attendence sheet</h4>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-responsive table-hover table-bordered table-sm">
                                        <thead class="thead-dark">
                                            <tr>
                                                <th>Employee</th>
                                                <th>Position</th>
                                                <?php
                                                $today = today();
                                                $dates = [];

                                                for ($i = 1; $i < $today->daysInMonth + 1; ++$i) {
                                                    $dates[] = \Carbon\Carbon::createFromDate($today->year, $today->month, $i)->format('Y-m-d');
                                                    }
                                                    ?>

                                                    <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <th>
                                                        <?php echo e($date); ?>

                                                    </th>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            <form action="<?php echo e(url('/check_store')); ?>" method="POST">
                                                <button type="submit" class="btn btn-success" style="display: flex; margin:10px">Submit attendance</button>
                                                <?php echo csrf_field(); ?>
                                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <input type="hidden" name="emp_id" value="<?php echo e($employee->id); ?>">
                                                <tr>
                                                    <td><?php echo e($employee->name); ?></td>
                                                    <td><?php echo e($employee->role); ?></td>
                                                    <?php for($i = 1; $i < $today->daysInMonth + 1; ++$i): ?>
                                                        <?php
                                                        $date_picker = \Carbon\Carbon::createFromDate($today->year, $today->month, $i)->format('Y-m-d');
                                                        $check_attd = \App\Models\Attendence::where('emp_id', $employee->id)
                                                        ->where('attendance_date', $date_picker)
                                                        ->first();
                                                        ?>
                                                        <td>
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" id="check_box" name="attd[<?php echo e($date_picker); ?>][<?php echo e($employee->id); ?>]" type="checkbox" <?php if(isset($check_attd)): ?> checked <?php endif; ?> id="inlineCheckbox1" value="1">
                                                            </div>
                                                        </td>
                                                        <?php endfor; ?>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </form>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH C:\Users\farha\OneDrive\Desktop\HotelManagementSystem-master\resources\views\admin\employee\check.blade.php ENDPATH**/ ?>